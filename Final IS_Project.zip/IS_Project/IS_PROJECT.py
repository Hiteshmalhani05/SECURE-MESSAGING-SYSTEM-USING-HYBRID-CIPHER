import os
import base64
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import hashes, hmac
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
from hashlib import sha256

# Predefined receiver keys (Public and Private)
RECEIVER_KEYS = {
    "Abdullah": "BDA-23F-028",
    "Ayesha": "BDA-24S-007",
    "Tufail": "BDA-23F-031",
    "Hitesh": "BDA-23F-007"
}

# Generate RSA Keys based on a unique identifier
def generate_rsa_keys(identifier):
    hashed_id = sha256(identifier.encode()).digest()  # Hash the identifier (name or private key)
    private_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=2048,
        backend=default_backend()
    )
    public_key = private_key.public_key()
    return private_key, public_key

# Encrypt Message using AES with RSA and HMAC
def encrypt_message(message, recipient_public_key):
    # Generate AES session key (32 bytes for AES-256)
    aes_key = os.urandom(32)

    # Encrypt message using AES
    iv = os.urandom(16)  # AES Initialization Vector
    cipher = Cipher(algorithms.AES(aes_key), modes.CFB(iv), backend=default_backend())
    encryptor = cipher.encryptor()
    ciphertext = encryptor.update(message.encode()) + encryptor.finalize()

    # Generate HMAC for the ciphertext
    h = hmac.HMAC(aes_key, hashes.SHA256(), backend=default_backend())
    h.update(ciphertext)
    hmac_value = h.finalize()

    # Encrypt AES key with recipient's RSA public key
    encrypted_key = recipient_public_key.encrypt(
        aes_key,
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None
        )
    )

    return base64.b64encode(ciphertext).decode(), base64.b64encode(iv).decode(), base64.b64encode(encrypted_key).decode(), base64.b64encode(hmac_value).decode()

# Decrypt Message using AES with RSA and HMAC
def decrypt_message(ciphertext, iv, encrypted_key, hmac_value, private_key):
    # Decode from base64
    ciphertext = base64.b64decode(ciphertext)
    iv = base64.b64decode(iv)
    encrypted_key = base64.b64decode(encrypted_key)
    hmac_value = base64.b64decode(hmac_value)

    # Decrypt AES session key using RSA private key
    aes_key = private_key.decrypt(
        encrypted_key,
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None
        )
    )

    # Verify HMAC to ensure integrity
    h = hmac.HMAC(aes_key, hashes.SHA256(), backend=default_backend())
    h.update(ciphertext)
    h.verify(hmac_value)  # Raises an error if the HMAC doesn't match

    # Decrypt the message using AES
    cipher = Cipher(algorithms.AES(aes_key), modes.CFB(iv), backend=default_backend())
    decryptor = cipher.decryptor()
    plaintext = decryptor.update(ciphertext) + decryptor.finalize()

    return plaintext.decode()

# Function to simulate user input for RSA keys 
def get_user_input():
    role = input("Are you a sender or receiver? (Enter 'sender' or 'receiver'): ").strip().lower()
    return role

def main():
    print("Welcome to the HATA Secure Messaging System Using Hybrid Cipher (AES, RSA, and HMAC)")

    # Pre-generate RSA keys for predefined receivers
    RSA_KEYS = {}
    for receiver, private_key_id in RECEIVER_KEYS.items():
        RSA_KEYS[receiver] = generate_rsa_keys(private_key_id)

    while True:
        role = get_user_input()

        if role == 'sender':
            print("\nSender Mode:")
            receiver_name = input("Enter the receiver's name : ").strip()
            
            # Check if the receiver name exists in predefined keys
            if receiver_name not in RSA_KEYS:
                print("Invalid receiver name. Please enter a valid receiver from the list.")
                continue

            # Get receiver's public key
            _, receiver_public_key = RSA_KEYS[receiver_name]

            message = input("Enter the message to encrypt: ").strip()

            # Encrypt the message with AES, RSA, and HMAC
            ciphertext, iv, encrypted_key, hmac_value = encrypt_message(message, receiver_public_key)

            # Store the encrypted message and key in a file
            with open("encrypted_message.txt", 'w') as f:
                f.write(f"Ciphertext: {ciphertext}\n")
                f.write(f"IV: {iv}\n")
                f.write(f"Encrypted AES Key: {encrypted_key}\n")
                f.write(f"HMAC: {hmac_value}\n")

            print("Message encrypted and stored in 'encrypted_message.txt'")

        elif role == 'receiver':
            print("\nReceiver Mode:")
            receiver_name = input("Enter your name : ").strip()
            
            # Validate receiver name
            if receiver_name not in RSA_KEYS:
                print("Invalid receiver name. Please enter a valid receiver from the list.")
                continue

            # Attempt to decrypt message with up to 3 attempts
            attempts = 0
            while attempts < 3:
                private_key_input = input("Enter your private key: ").strip()

                # Check if the private key matches
                if private_key_input == RECEIVER_KEYS[receiver_name]:
                    receiver_private_key, _ = RSA_KEYS[receiver_name]
                    try:
                        # Read the encrypted message file
                        with open("encrypted_message.txt", 'r') as f:
                            lines = f.readlines()
                            ciphertext = lines[0].split("Ciphertext: ")[1].strip()
                            iv = lines[1].split("IV: ")[1].strip()
                            encrypted_key = lines[2].split("Encrypted AES Key: ")[1].strip()
                            hmac_value = lines[3].split("HMAC: ")[1].strip()

                        # Decrypt the message
                        decrypted_message = decrypt_message(ciphertext, iv, encrypted_key, hmac_value, receiver_private_key)
                        print("Decrypted Message:", decrypted_message)
                        break
                    except Exception as e:
                        print(f"Error occurred during decryption: {e}")
                        break
                else:
                    print("Incorrect private key. Please try again.")
                    attempts += 1

            if attempts == 3:
                print("Maximum attempts reached. Exiting the program.")
                break

        else:
            print("Invalid role, please choose 'sender' or 'receiver'.")

        cont = input("\nDo you want to continue? (y/n): ").strip().lower()
        if cont != 'y':
            break

if __name__ == "__main__":
    main()
